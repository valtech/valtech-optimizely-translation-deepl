define("epi-cms/contentediting/command/AccessRights", [
    "require",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/json",
    "dojo/Deferred",
    "dojo/on",
    "dojo/topic",
    "epi/dependency",
    "epi-cms/contentediting/ContentActionSupport",
    "epi/shell/command/_Command",
    "epi/shell/widget/dialog/Dialog",
    "epi-cms/ApplicationSettings",
    //Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.contentdetails.command.accessrights",
    "epi/i18n!epi/shell/nls/admin.security",
    "epi/i18n!epi/shell/nls/admin.searchusers",
    "epi/i18n!epi/shell/nls/edit.editsecurity",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.hierachicallist",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.contentreferences",
    "epi/i18n!epi/shell/nls/button",
    "epi/i18n!epi/nls/episerver.shared"
],

function (
    moduleRequire,
    declare,
    lang,
    json,
    Deferred,
    on,
    topic,
    dependency,
    ContentActionSupport,
    _Command,
    Dialog,
    ApplicationSettings,
    resources,
    securityResources,
    searchusersResources,
    editsecurityResources,
    hierachicalListResources,
    contentReferencesResources,
    buttonResources,
    sharedResources) {

    function AccessRightsViewModel(store) {

        return {
            onMessage: function (message) {
                // callback
            },
            searchVirtualRoles: function (searchPhrase, startIndex, maxRows) {
                return store.query({ type: "VirtualRoles", partOfName: searchPhrase }, { start: startIndex, count: maxRows });
            },
            searchRoles: function (searchPhrase, startIndex, maxRows) {
                return store.query({ type: "Roles", partOfName: searchPhrase }, { start: startIndex, count: maxRows });
            },
            searchVisitorGroups: function (searchPhrase, startIndex, maxRows) {
                return store.query({ type: "VisitorGroups", partOfName: searchPhrase }, { start: startIndex, count: maxRows });
            },
            searchApplications: function (searchPhrase, startIndex, maxRows) {
                return store.query({ type: "Applications", partOfName: searchPhrase }, { start: startIndex, count: maxRows });
            },
            searchUsers: function (searchPhrase, startIndex, maxRows) {
                return store.query({ type: "Users", partOfName: searchPhrase }, { start: startIndex, count: maxRows });
            }
        };
    }

    return declare([_Command], {
        // summary:
        //      Toggles permanent in use notification on/off.
        //
        // tags:
        //      internal

        name: "AccessRights",
        label: resources.label,
        tooltip: resources.tooltip,
        store: null,
        accessrightUsersStore: null,

        constructor: function (params) {
            declare.safeMixin(this, params);
            this.store = this.store || dependency.resolve("epi.storeregistry").get("epi.cms.accessrights");
            this.accessrightUsersStore = this.accessrightUsersStore || dependency.resolve("epi.storeregistry").get("epi.cms.accessright.users");
        },

        _execute: function () {
            moduleRequire(["epi-cms-react/components/content-access-rights-widget", "xstyle/css!epi-cms-react/components/content-access-rights-widget.css"], function (ContentAccessRightsWidget) {
                var resources = Object.assign({}, securityResources, searchusersResources, editsecurityResources, buttonResources, hierachicalListResources, contentReferencesResources, {
                    heading: lang.replace(editsecurityResources.heading, [this.model.contentData.name]),
                    user: lang.replace(editsecurityResources.user, [ApplicationSettings.userName])
                });
                var model = AccessRightsViewModel(this.accessrightUsersStore);

                this.store.get(this.model.contentData.contentLink).then(function (settings) {
                    var dialog;
                    var content = new ContentAccessRightsWidget({
                        model: model,
                        resources: resources,
                        helpLink: ApplicationSettings.userGuideUrl + "#editsecurity",
                        entries: settings.entries,
                        isInherited: settings.isInherited,
                        isInheritedEnabled: settings.isInheritedEnabled,
                        userGroups: settings.userGroups,
                        onDirty: function (isDirty) {
                            if (!dialog) {
                                return;
                            }

                            dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", !isDirty);
                        }
                    });
                    dialog = new Dialog({
                        dialogClass: "epi-dialog-portrait epi-dialog-portrait__autosize epi-dialog--wide",
                        defaultActionsVisible: true,
                        confirmActionText: sharedResources.action.save,
                        content: content,
                        title: editsecurityResources.title
                    });

                    dialog.addValidator(function () {
                        var deferred = new Deferred();
                        this.store.executeMethod("Save", this.model.contentData.contentLink, {
                            entries: model.entries,
                            id: this.model.contentData.contentLink,
                            isInherited: model.isInherited
                        }).then(function () {
                            model.onMessage(editsecurityResources.savemessage);
                            dialog.hide();
                            topic.publish("/epi/cms/contentdata/updated", {
                                contentLink: this.model.contentData.contentLink,
                                recursive: true
                            });
                            return deferred.resolve([]);
                        }.bind(this)).otherwise(function (response) {
                            model.onMessage(response.responseText ? json.fromJson(response.responseText) : "");
                        });
                        return deferred.promise;
                    }.bind(this));

                    dialog.show();
                    dialog.definitionConsumer.setItemProperty(dialog._okButtonName, "disabled", true);

                }.bind(this));
            }.bind(this));
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //		protected

            var contentData = this.model.contentData,
                hasAdminAccess = ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Administer);

            this.set("canExecute", contentData.capabilities.securable && hasAdminAccess);
        }
    });
});
